<bo?php $lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : 'UA';
$translations = include "$lang.php";

?>

</main>
<footer>
    <p>Загальна кількість переглядів: <?php echo getPageViews($conn); ?></p>
</footer>
</body>
</html>