<?php
return [
    'Головна' => 'Main',
    'Довідник' => 'Directory',
    'Майстерня Майстра' => 'Master\'s workshop',
    'Аккаунт' => 'Account',
    'Змінити мову' => 'Switch Language',
    'Вихід' => 'Exit',
    'Реєстрація' => 'Registration',
    'Вхід' => 'Entry',
    'Це головна сторінка' => 'This is the main page'
];